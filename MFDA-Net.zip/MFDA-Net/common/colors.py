"""Useful color codes"""
ORANGE = [239, 124, 0]
BLUE = [0, 61, 124]